const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');


function sidebarOpen() {
    sidebar.style.left = "0";
    overlay.style.display = "block";
}

function sidebarClose() {
    sidebar.style.left = "-100%";
    overlay.style.display = "none";
}