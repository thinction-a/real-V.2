// HEADER__CENTER__SCROLL_TOP_ANIMATE
const clickThis = document.querySelector('.center');
clickThis.addEventListener('click', () => window.scrollTo({
    top: 0,
    behavior: 'smooth'
}));

// SECTION__KEYWORD__CONTENT_DEVICE_ON&OFF
const device1 = document.getElementsByClassName('device1');
const device2 = document.getElementsByClassName('device2');
const device3 = document.getElementsByClassName('device3');

const guideline1 = document.getElementsByClassName('guideline1');
const guideline2 = document.getElementsByClassName('guideline2');
const guideline3 = document.getElementsByClassName('guideline3');


$(device1).on('click', function() {
    $(device1).addClass('selected');
    $(guideline1).css('display', 'block');
    $(device2).removeClass('selected');
    $(device3).removeClass('selected');
    $(guideline2).css('display', 'none');
    $(guideline3).css('display', 'none');
});
$(device2).on('click', function() {
    $(device2).addClass('selected');
    $(guideline2).css('display', 'block');
    $(device1).removeClass('selected');
    $(device3).removeClass('selected');
    $(guideline1).css('display', 'none');
    $(guideline3).css('display', 'none');
});
$(device3).on('click', function() {
    $(device3).addClass('selected');
    $(guideline3).css('display', 'block');
    $(device1).removeClass('selected');
    $(device2).removeClass('selected');
    $(guideline1).css('display', 'none');
    $(guideline2).css('display', 'none');
});

// SECTION__KEYWORD__CONTENT_TAGS_ON&OFF
const btn = document.querySelectorAll('tr>.btn');
const wantTd = Object.values(btn);

function testing2() {
    this.classList.toggle('clicked')
}


function init(){
    for (let i = 0; i < wantTd.length; i++) {
    wantTd[i].addEventListener("click", testing2);
    }
}
init();

// SECTION__REVIEW__TOGGLEBTN_ON&OFF
const recent = document.querySelector('.recent');
const popular = document.querySelector('.popular');
const buttons = document.querySelectorAll('.toggle--wrapper>button')
const _buttons = Object.values(buttons);

function colored() {
    recent.addEventListener('click', function() {
        recent.classList.add('focused');
        popular.classList.remove('focused');
    });
    popular.addEventListener('click', function() {
        popular.classList.add('focused');
        recent.classList.remove('focused');
    });
};

function focused() {
    for (let i = 0; i < _buttons.length; i++) {
        _buttons[i].addEventListener("click", colored);   
    }
};
focused();

// SECTION__REVIEW__LIKE||UNLIKE_SWITCH
const likeBtnGroup = document.querySelectorAll('.likeBtn');
// likeBtnGroup을 Array로 변환
const _likeBtnGroup = Object.values(likeBtnGroup);
console.log(_likeBtnGroup)

const _likeBtnFilledGroup = document.querySelectorAll('.likeBtn');

function Func_likeBtnFilled() {
    if (this.src = './images/functionBtn/review_like.svg') {
        this.src = './images/functionBtn/review_like_filled.svg';
    }
};

function likeBtnClicked() {
    for (let i = 0; i < _likeBtnGroup.length; i++) {
        _likeBtnGroup[i].addEventListener('click', Func_likeBtnFilled);
    }
};
likeBtnClicked();






// function Func_likeBtnFilled() {
//     likeBtn.addEventListener('click', function() {
//         likeBtn.style.display = 'none';
//         likeBtnFilled.style.display = 'block';
//     })
//     likeBtnFilled.addEventListener('click', function() {
//         likeBtn.style.display = 'block';
//         likeBtnFilled.style.display = 'none';
//     })
// }
// Func_likeBtnFilled();


const unlikeBtnGroup = document.querySelectorAll('.unlikeBtn>img');
const _unlikeBtnGroup = Object.values(unlikeBtnGroup);
const unlikeBtn = _unlikeBtnGroup[0];
const unlikeBtnFilled = _unlikeBtnGroup[1];

function Func_unlikeBtnFilled() {
    unlikeBtn.addEventListener('click', function() {
        unlikeBtn.style.display = 'none';
        unlikeBtnFilled.style.display = 'block';
    })
    unlikeBtnFilled.addEventListener('click', function() {
        unlikeBtn.style.display = 'block';
        unlikeBtnFilled.style.display = 'none';
    })
}
Func_unlikeBtnFilled();