/* /////////////////////////////////////////////////////////////////////////////////////////////////////////
@ 작성자 : JEON
@ 작성일 : 2015-01-30
@ 설   명 : 연혁 UI 
@ 수정사항
	수정일           수정자    수정내용
	0000-00-00     홍길동    수정내용
/////////////////////////////////////////////////////////////////////////////////////////////////////////*/
function HistoryUI(){
	$(".history-area ol strong").click(function(){
		var vv = $(this).parent().index();
		var vvv = $(this).parent().parents("li").index();

		if($(this).parent().hasClass("on")){
			$(this).next().slideUp().parent().removeClass("on");
			$(".history-area li li").css("opacity", 1);
			return false;
		}

		$(".history-area ol li").removeClass("on");
		$(this).parent().addClass("on");
		$(this).next().slideDown().parent().siblings().find("p").slideUp().parent().parents("li").siblings().find("p").slideUp();
		$(this).parent().css("opacity", 1).siblings().css("opacity", 0.6).parents("li").siblings().find("li").css("opacity", 0.6);

	});
}

/* /////////////////////////////////////////////////////////////////////////////////////////////////////////
@ 작성자 : JEON
@ 작성일 : 2015-02-25
@ 설   명 : Swipe toggle button UI 
@ 수정사항
	수정일           수정자    수정내용
	0000-00-00     홍길동    수정내용
/////////////////////////////////////////////////////////////////////////////////////////////////////////*/
function swipeToggleEvent(){
	$(".btn-onoff button").on("swiperight", swipeR);
	$(".btn-onoff button").on("swipeleft", swipeL);
	
	var _width = $(".btn-onoff").width();
	var _widthb = $(".btn-onoff button").width();
	
	function swipeR(event){
		$(this).removeClass("btn-on").addClass("btn-off").val("off");
		$(this).animate({"left": _width - _widthb +"px"}, "swing" );
	}
	function swipeL(event){
		$(this).removeClass("btn-off").addClass("btn-on").val("on");
		$(this).animate({"left": 1+"px"}, "swing");
	}

	$(".btn-onoff").click(function(){
		if($("button", this).hasClass("btn-on")){
			$("button", this).removeClass("btn-on").addClass("btn-off").val("off");
			$("button", this).animate({"left": _width - _widthb +"px"}, "swing" );
		}else{
			$("button", this).removeClass("btn-off").addClass("btn-on").val("on");
			$("button", this).animate({"left": 1+"px"}, "swing");
		}
	})
}